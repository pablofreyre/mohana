package edu.unicauca.mohana;


import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

public class main_femenino extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ly_femenino);
    }
}
